export class Test {
    name:string;
    age:number;
    constructor(values:Object={}){
        Object.assign(this,values);
    }
    
}
